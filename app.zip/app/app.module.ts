import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; // <-- NgModel lives here

import { AppComponent } from './app.component';
import { DashboardComponent }   from './dashboard/dashboard.component';
import { NamesComponent } from './names/names.component';
import { NameDetailComponent } from './name-detail/name-detail.component';

import { NameService } from './name.service';
import { MessageService } from './message.service';
import { MessagesComponent } from './messages/messages.component';

import { AppRoutingModule }     from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    NamesComponent,
    NameDetailComponent,
    MessagesComponent,
  ],
  imports: [
  BrowserModule,
	FormsModule,
  AppRoutingModule,
  ],
  providers: [
    NameService,
    MessageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
