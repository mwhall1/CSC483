import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-name-search',
  templateUrl: './name-search.component.html',
  styleUrls: ['./name-search.component.css']
})
export class NameSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
