export class Name {
  id: number;
  name: string;
}