import { Component, OnInit } from '@angular/core';
import { Name } from '../name';

@Component({
  selector: 'app-names',
  templateUrl: './names.component.html',
  styleUrls: ['./names.component.css']
})
export class NamesComponent implements OnInit {
 names: Name = {
	  id: 1,
	  name: 'Joel'
  };
  constructor() { }

  ngOnInit() {
  }

}
