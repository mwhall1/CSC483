import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-name-detail',
  templateUrl: './name-detail.component.html',
  styleUrls: ['./name-detail.component.css']
})
export class NameDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
